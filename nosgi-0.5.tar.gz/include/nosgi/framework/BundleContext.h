/*
 * nOSGi Project - http://www-vs.informatik.uni-ulm.de/proj/nosgi/
 *
 * Copyright (C) 2009-2011 Aspectix Research Team,
 * Institute of Distributed Systems, Ulm University, Germany
 *
 * This file is part of the nOSGi Project, which is released
 * under the terms of the GNU General Public License.
 * See the LICENSE.txt file in the root directory of the software
 * distribution for more details.
 */

#ifndef BUNDLECONTEXT_H
#define BUNDLECONTEXT_H

#include <nosgi/framework/Bundle.h>
#include <nosgi/framework/BundleListener.h>
#include <nosgi/framework/BundleException.h>
#include <nosgi/framework/Property.h>
#include <nosgi/framework/ServiceListener.h>
#include <nosgi/framework/ServiceReference.h>
#include <nosgi/framework/ServiceRegistration.h>
#include <string>
#include <map>
#include <vector>

using namespace std;

class Bundle;
class BundleListener;

class BundleContext {
	public:
		BundleContext();
		ServiceRegistration *registerService(string &interfaceName,
			void *service);
		ServiceRegistration *registerService(string &interfaceName,
			void *service, map<string,Property*> *properties);
		void addBundleListener(BundleListener *listener);
		void removeBundleListener(BundleListener *listener);
		void addServiceListener(ServiceListener *listener);
		void addServiceListener(ServiceListener *listener, string filter);
		void removeServiceListener(ServiceListener *listener);
		Bundle *getBundle(long id) const;
		vector<Bundle *> *getBundles() const;
		void *getService(const ServiceReference *ref) const;
		ServiceReference *getServiceReference(
			const string &interfaceName) const;
		Bundle *installBundle(const string& location) const
			throw(BundleException);
		void printBundles();
		void printServices() const;

	private:
		string getStateString(int state);
};

#endif
