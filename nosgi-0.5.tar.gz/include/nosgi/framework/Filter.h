/*
 * nOSGi Project - http://www-vs.informatik.uni-ulm.de/proj/nosgi/
 *
 * Copyright (C) 2009-2011 Aspectix Research Team,
 * Institute of Distributed Systems, Ulm University, Germany
 *
 * This file is part of the nOSGi Project, which is released
 * under the terms of the GNU General Public License.
 * See the LICENSE.txt file in the root directory of the software
 * distribution for more details.
 */

#ifndef NOSGI_FRAMEWORK_FILTER_H
#define NOSGI_FRAMEWORK_FILTER_H

#include <map>
#include <string>
#include <nosgi/framework/Property.h>
#include <nosgi/framework/ServiceReference.h>

class Filter {
public:
	virtual bool match(const ServiceReference &ref) = 0;
	virtual bool match(const map<string,Property*> *r) = 0;
	//virtual string toString() = 0;
};

#endif
