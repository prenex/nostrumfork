/*
 * nOSGi Project - http://www-vs.informatik.uni-ulm.de/proj/nosgi/
 *
 * Copyright (C) 2009-2011 Aspectix Research Team,
 * Institute of Distributed Systems, Ulm University, Germany
 *
 * This file is part of the nOSGi Project, which is released
 * under the terms of the GNU General Public License.
 * See the LICENSE.txt file in the root directory of the software
 * distribution for more details.
 */

#ifndef BUNDLE_H
#define BUNDLE_H

#include <string>
#include <vector>
#include <nosgi/classloader/NOSGiClassLoader.h>
#include <nosgi/framework/BundleActivator.h>
#include <nosgi/framework/BundleContext.h>
#include <nosgi/framework/BundleException.h>
#include <nosgi/framework/Version.h>
#include <nosgi/service/Package.h>
#include <nosgi/service/NeededPackage.h>

using namespace std;

class BundleActivator;
class BundleContext;
class Package;
class NeededPackage;

class Bundle {
public:
	enum bundleState { //see Spec 6.1.4
		UNINSTALLED = 1,
		START_TRANSIENT = 1,
		STOP_TRANSIENT = 1,
		INSTALLED = 2,
		RESOLVED = 4,
		STARTING = 8,
		STOPPING = 16,
		ACTIVE = 32
	};
	Bundle(const string& name) throw(BundleException);
	Bundle(long bundleId);
	~Bundle();
	long getBundleId() const;
	string &getLocation();
	string &getSymbolicName();
	string getVersionString();
	int getState() const;
	void start() throw(BundleException);
	void stop();
	void uninstall() throw(BundleException);
	void update() throw(BundleException);
	void doupdate();
	Package *isExport(string &package) const;

private:
	bool parseManifest(const string &location);
	//string getDirName(const string &filename);
	void resolveAndLoad(bool setBundleId) throw(BundleException);
	void resolve();
	void addImports(const string &file, bool setBundleId) const;
	void exportPackages(bool setBundleId) const;
	void unExportPackages();
	Version *doResolve(Package *package, NeededPackage *neededPackage,
		                Version *version, long bid);
	void doUninstall();
	bundleState state;
	Version version;
	long bundleId;
	string location;
	string cachelocation;
	string symbolicName;
	BundleActivator *activator;
	NOSGiClassLoader *classLoader;
	string activatorName;
	BundleContext *context;
	vector<NeededPackage *> imports;
	vector<Package *> exports;
	bool sourcebundle;
};

#endif
