/*
 * nOSGi Project - http://www-vs.informatik.uni-ulm.de/proj/nosgi/
 *
 * Copyright (C) 2009-2011 Aspectix Research Team,
 * Institute of Distributed Systems, Ulm University, Germany
 *
 * This file is part of the nOSGi Project, which is released
 * under the terms of the GNU General Public License.
 * See the LICENSE.txt file in the root directory of the software
 * distribution for more details.
 */

#ifndef NOSGI_FRAMEWORK_FRAMEWORKEVENT_H
#define NOSGI_FRAMEWORK_FRAMEWORKEVENT_H

#include <nosgi/framework/Bundle.h>
#include <exception>

class FrameworkEvent {
public:
	enum frameworkEvent {
		STARTED = 0x0001,
		ERROR = 0x0002,
		PACKAGES_REFRESHED = 0x0004,
		STARTLEVEL_CHANGED = 0x0008,
		WARNING = 0x0010,
		INFO = 0x0020
	};
	FrameworkEvent(int type, Bundle *bundle, exception *except);
	Bundle *getBundle() const;
	exception *getException() const;
	int getType() const;

private:
	int type;
	Bundle *bundle;
	exception *except;
};

#endif
