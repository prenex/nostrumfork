/*
 * nOSGi Project - http://www-vs.informatik.uni-ulm.de/proj/nosgi/
 *
 * Copyright (C) 2009-2011 Aspectix Research Team,
 * Institute of Distributed Systems, Ulm University, Germany
 *
 * This file is part of the nOSGi Project, which is released
 * under the terms of the GNU General Public License.
 * See the LICENSE.txt file in the root directory of the software
 * distribution for more details.
 */

#ifndef NOSGI_FRAMEWORK_BUNDLEEVENT_H
#define NOSGI_FRAMEWORK_BUNDLEEVENT_H

#include <nosgi/framework/Bundle.h>

class Bundle;

class BundleEvent {
public:
	enum bundleEvent {
		INSTALLED = 0x0001,
		STARTED = 0x0002,
		STOPPED = 0x0004,
		UPDATED = 0x0008,
		UNINSTALLED = 0x0010,
		RESOLVED = 0x0020,
		UNRESOLVED = 0x0040,
		STARTING = 0x0080,
		STOPPING = 0x0100,
		LAZY_ACTIVATION = 0x0200
	};
	BundleEvent(int type, Bundle &bundle);
	Bundle &getBundle() const;
	int getType() const;

private:
	int type;
	Bundle &bundle;
};

#endif
