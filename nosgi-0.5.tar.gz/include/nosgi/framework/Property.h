/*
 * nOSGi Project - http://www-vs.informatik.uni-ulm.de/proj/nosgi/
 *
 * Copyright (C) 2009-2011 Aspectix Research Team,
 * Institute of Distributed Systems, Ulm University, Germany
 *
 * This file is part of the nOSGi Project, which is released
 * under the terms of the GNU General Public License.
 * See the LICENSE.txt file in the root directory of the software
 * distribution for more details.
 */

#ifndef NOSGI_FRAMEWORK_PROPERTY_H
#define NOSGI_FRAMEWORK_PROPERTY_H

#include <string>

using namespace std;

class Property {
public:
	enum types {
		STRING = 0,
		INT,
		LONG,
		SHORT,
		FLOAT,
		DOUBLE
	};
	Property(string *s);
	Property(int i);
	Property(long l);
	Property(float f);
	Property(double d);
	Property(bool b);
	Property(char c);
	~Property();
	string *getString();
	short getType() const;
	int getInt() const;
	long getLong() const;
	short getShort() const;
	float getFloat() const;
	double getDouble() const;

private:
	union {
		string *s;
		int i;
		long l;
		short sh;
		float f;
		double d;
		char c;
		bool b;
	} value;
	short type;
};

#endif
