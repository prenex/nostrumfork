/*
 * nOSGi Project - http://www-vs.informatik.uni-ulm.de/proj/nosgi/
 *
 * Copyright (C) 2009-2011 Aspectix Research Team,
 * Institute of Distributed Systems, Ulm University, Germany
 *
 * This file is part of the nOSGi Project, which is released
 * under the terms of the GNU General Public License.
 * See the LICENSE.txt file in the root directory of the software
 * distribution for more details.
 */

#ifndef NOSGI_FRAMEWORK_PACKAGE_H
#define NOSGI_FRAMEWORK_PACKAGE_H

#include <nosgi/framework/Version.h>
#include <nosgi/framework/Bundle.h>
#include <nosgi/service/ExportedPackage.h>
#include <string>

using namespace std;

class Package : ExportedPackage {
public:
	Package(const string &name);
	Package(const string &name, const Version &version);
	string getName() const;
	Bundle &getExportingBundle();
	Bundle *getImportingBundle();
	Version &getVersion();
	bool isRemovalPending() const;

	void setBundleId(long newBundleId);
	long getBundleId() const;
	void decImports();
	void incImports();
	bool isImported() const;

private:
	string name;
	Version version;
	long bundleId;
	int imports;
};

#endif
