/*
 * nOSGi Project - http://www-vs.informatik.uni-ulm.de/proj/nosgi/
 *
 * Copyright (C) 2009-2011 Aspectix Research Team,
 * Institute of Distributed Systems, Ulm University, Germany
 *
 * This file is part of the nOSGi Project, which is released
 * under the terms of the GNU General Public License.
 * See the LICENSE.txt file in the root directory of the software
 * distribution for more details.
 */

#ifndef NOSGI_CLASSLOADER_NOSGICLASSLOADER_H
#define NOSGI_CLASSLOADER_NOSGICLASSLOADER_H

#include <string>
#include <map>

class NOSGiClassLoader {
	public:
		NOSGiClassLoader();
		virtual ~NOSGiClassLoader();

		virtual void setClassPath(const std::string &pathlist);
		virtual void *loadActivator(const std::string &className);
		virtual void releaseActivator(const std::string &className);
		virtual void loadSo(const std::string &soName);
		virtual void releaseSo(const std::string &soName);
		virtual void releaseAllSo();

	private:
		std::string classPath;
		std::map<std::string, void *> loaded;
		std::map<std::string, unsigned int> used;
		std::map<std::string, void *> loadedso;
};

#endif
