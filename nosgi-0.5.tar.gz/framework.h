/*
 * nOSGi Project - http://www-vs.informatik.uni-ulm.de/proj/nosgi/
 *
 * Copyright (C) 2009-2011 Aspectix Research Team,
 * Institute of Distributed Systems, Ulm University, Germany
 *
 * This file is part of the nOSGi Project, which is released
 * under the terms of the GNU General Public License.
 * See the LICENSE.txt file in the root directory of the software
 * distribution for more details.
 */

#ifndef FRAMEWORK_H
#define FRAMEWORK_H

#include <nosgi/framework/Bundle.h>
#include <nosgi/framework/BundleListener.h>
#include <nosgi/framework/Filter.h>
#include <nosgi/framework/FrameworkListener.h>
#include <nosgi/framework/ServiceReference.h>
#include <nosgi/framework/ServiceListener.h>
#include <map>
#include <vector>
#include <set>
#include <stdlib.h>
#include <string>

using namespace std;

class Framework {
public:
	static Bundle *installBundle(Bundle *bundle);
	static Bundle *getBundle(long id);
	static multimap<string,Bundle *> *getBundles();
	static vector<Bundle *> *getInstalledBundles();
	static void uninstallBundle(long id);
	static void addFrameworkListener(FrameworkListener *listener);
	static void notifyFrameworkListeners(FrameworkEvent &event);
	static void removeFrameworkListener(FrameworkListener *listener);
	static void addBundleListener(BundleListener *listener);
	static void notifyBundleListeners(BundleEvent &event);
	static void removeBundleListener(BundleListener *listener);
	static void addServiceListener(ServiceListener *listener, Filter *filter);
	static void notifyServiceListeners(ServiceEvent &event);
	static void removeServiceListener(ServiceListener *listener);
	static void addServiceRegistration(long id, void *);
	static void *getService(const ServiceReference *ref);
	static void removeServiceRegistration(long id);
	static void printServices();
	static void addInterfaceRegistration(ServiceReference *ref,
			const string &interface);
	static ServiceReference *getServiceReference(
			const string &interfaceName);
	static void removeInterfaceRegistration(long id,
			const string &interface);
	static long getNextBundleId();
	static long getNextServiceId();
	static void preload();
	static void startup();
	static void shutdown();

private:
	static set<FrameworkListener *> frameworkListeners;
	static set<BundleListener *> syncBundleListeners;
	static map<ServiceListener *, Filter *> serviceListeners;
	static map<long,void *> serviceRegistry;
	static multimap<string,ServiceReference *> interfaceRegistry;
	static long bid;
	static long fid;
};

#endif
